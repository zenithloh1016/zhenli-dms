# ZHENLI DMS — Direct Create Signing Request v2

This release ADDS an embedded form BELOW the **existing EdgeOne service** card; it does NOT replace the old external website link or its familiar dashboard. The existing Tencent EdgeOne backend remains the signing/document engine and all original drafts and PDFs stay stored there.

**Not deployed.** Both repositories must be updated and the 4 server-side EdgeOne settings installed. Test using nonconfidential documents before production.

## REQUIRED ORDER: Backend FIRST, then DMS UI

### A. EdgeOne repository (`zenithloh1016/ZHENLI-Sequential-Signing`)

1. Backup the repository and the EdgeOne private Blob data using its own approved export/backup process. Existing signer links and signed PDFs are not included in this ZIP.
2. Upload this ZIP via GitHub to the original EdgeOne repository (keep on private test branch when possible), then in Codespaces Terminal run:

```sh
cd /workspaces/ZHENLI-Sequential-Signing
git pull --ff-only origin main
unzip -o ZHENLI_DMS_Direct_Signing_Keep_Existing_v2.zip 'edgeone/scripts/apply_dms_connector.py'
wc -c edgeone/scripts/apply_dms_connector.py
```

**Expect ~5500 bytes (not zero).** If zero bytes, STOP. Then:

```sh
cp 'cloud-functions/api/[[default]].js' /tmp/zhenli-edgeone-before-dms.js
python3 edgeone/scripts/apply_dms_connector.py
node --check 'cloud-functions/api/[[default]].js'
git diff --stat
```

Check `git diff`: it must ONLY add authenticated DMS routes to `cloud-functions/api/[[default]].js`, without replacing the existing signing engine. Do NOT commit/push until EdgeOne settings are configured and you are ready to deploy. If the patch prints an unexpected anchor, STOP and get the current source inspected.

3. Tencent EdgeOne Pages → `zhenli-sequential-signing` → Settings → Environment Variables (server only), set EXACTLY these four:

| Name | Value |
|---|---|
| `DMS_SUPABASE_URL` | Project base URL `https://...supabase.co` |
| `DMS_SUPABASE_PUBLISHABLE_KEY` | Supabase browser-safe publishable/anon key (not service role!) |
| `DMS_ADMIN_UID` | UUID for the one permitted confirmed user, from Supabase Authentication → Users |
| `DMS_ALLOWED_ORIGINS` | `https://zenithloh1016.github.io,https://localhost` |

Never post actual values, admin passwords, signing tokens, or secret keys in chat or GitHub. Ensure `APP_SECRET`, `ADMIN_PASSWORD`, and SMTP environment variables remain unchanged.

4. After configuration, commit **only the two patched source files** and REMOVE the ZIP from public GitHub repo:

```sh
git add 'cloud-functions/api/[[default]].js' edgeone/scripts/apply_dms_connector.py
git rm -- ZHENLI_DMS_Direct_Signing_Keep_Existing_v2.zip
git commit -m 'Add verified DMS signing API'
git push origin main
```

Confirm EdgeOne production deployment succeeds. **Do not test using real client records yet.** The EdgeOne signed-PDF store is preserved by this source-only patch; verify with a sample before trusting it.

### B. DMS repository (`zenithloh1016/zhenli-dms`)

**First finish/push previous `git revert 51ee659`** (the rollback restoring the EdgeOne service card) and verify the workspace is clean. If that revert is currently staged but not committed, commit it before applying this add-on.

1. Upload this same ZIP to DMS GitHub repository, then Codespaces Terminal:

```sh
cd /workspaces/zhenli-dms
git pull --ff-only origin main
unzip -o ZHENLI_DMS_Direct_Signing_Keep_Existing_v2.zip 'scripts/apply_signing_update.py' 'src/signing-workspace.js' 'src/signing-workspace.css'
python3 scripts/apply_signing_update.py
node --check src/main.js
node --check src/integrated-modules.js
node --check src/signing-workspace.js
npm install --no-audit --no-fund
npm run build
```

Expected message: `DMS signing form added BELOW original EdgeOne service panel.`

2. Verify GitHub Actions repository variables `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, and `VITE_EDGEONE_SIGNING_URL` remain present. Stage only the updated source and workflow (do not stage `.env`, downloaded client documents, or old ZIPs):

```sh
git add src/main.js src/integrated-modules.js src/signing-workspace.js src/signing-workspace.css scripts/apply_signing_update.py .github/workflows/deploy.yml
git rm -- ZHENLI_DMS_Direct_Signing_Keep_Existing_v2.zip
git commit -m 'Add direct signing requests while keeping EdgeOne portal'
git push origin main
```

3. Wait for BOTH GitHub Actions jobs (web and Android) to pass, update APK from the **new** artifact, then open the DMS Signing tab.

## In-DMS signing flow

- Old 'Existing EdgeOne service' panel/link remains at top.
- Below, 'Sequential Signing Requests' form appears with **Create request**.
- Select a DMS company, upload PDF (8 docs max, each 3 MB max) or select a DMS PDF, enter subject and signer order, create draft.
- Set numeric signature field coordinates by signer, document and page (original EdgeOne visual editor remains available for visual placement), save, activate, and send invitations.
- Signers sign on original Tencent EdgeOne site, DMS displays statuses; after completion manually save signed PDFs into DMS.

## Errors

- `Failed to fetch`: EdgeOne backend not yet deployed, URL invalid, or browser blocked CORS. DO NOT disable CORS or RLS; check the `/api/dms/requests` endpoint and `DMS_ALLOWED_ORIGINS`.
- `401 DMS administrator authorization failed`: the specific confirmed Supabase Auth UID mismatch, invalid publishable key or invalid DMS user token.
- `404` on `/api/dms/requests`: backend bridge not applied/published or wrong EdgeOne domain.
- Installer reports `Already patched`: current DMS or EdgeOne code still includes earlier in-app integration; do not run this on a mixed or unreverted version.

**Caution:** This is a pilot electronic-signature workflow, not a certified digital-signature solution. Review regulatory/evidentiary suitability and consent for each statutory document. The signing server has known concurrency limitations; validate multi-signer flows carefully.
