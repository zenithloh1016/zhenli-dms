# ZHENLI — DMS + Task Hub V3 + Sequential Signing (web and Android)

## What this update DOES

- Retains your current `zhenli-dms` Supabase DMS and the existing 11 statutory folder categories.
- Adds Overview, Documents, Secretarial Task Hub, Sequential Signing tabs (including mobile navigation).
- Bundles the **original public Task Hub V3** (tasks, checklists, statuses, priorities, Kanban board, calendar, AR/AFS deadline view, recurring tasks, activity, backup import/export).
- When Task Hub is opened **inside a signed-in DMS session**, uses a secure Supabase `task_hub_state` table with per-user Row Level Security and saves task changes to cloud. The first load merges missing company names from the DMS portfolio. It does NOT overwrite existing task history or AR/AFS dates.
- Keeps Tencent EdgeOne Sequential Signing **at its original URL and with its original backend**: draft creation, signer order, placing signature boxes, activation, mail, signing, audit ZIP, delete-draft fix, PDF viewer fix all remain with the existing EdgeOne project. The DMS opens the original page; it does NOT attempt to transplant EdgeOne Cloud Functions to GitHub Pages.
- Repair for two original Excel parser defects, only when those defects have not already been fixed in the live DMS code.
- Preserves Supabase URL/registration fixes already applied to the live GitHub repository, by patching rather than replacing `src/main.js`.

## Limits / not yet included

- The existing EdgeOne sign-in and Supabase DMS sign-in are **separate**. There is NO single sign-on.
- No automatic EdgeOne-signed PDF auto-filing in DMS, no automatic signing-status → task-status updates. Download final PDF + audit ZIP from EdgeOne and manually file to DMS after review. These features need a secure authenticated server integration and further testing.
- Task Hub on its old EdgeOne site uses its own browser localStorage; it does NOT automatically sync to the new DMS. On the OLD Task Hub website, export a JSON backup, then in NEW integrated Task Hub use **Data & Settings → Import backup**. The import is private to your authenticated Supabase account and is saved there. Export another backup after migration.
- Task Hub embedded cloud synchronization is per authenticated DMS user. It uses last-write-wins; concurrent edits on two devices can overwrite each other. Do not edit simultaneously until conflict handling is added.
- Task Hub bundled files (without embedded private client data) are served as static assets on GitHub Pages. If opened directly outside the authenticated DMS wrapper, they behave as the old standalone LOCAL browser-storage edition, not cloud synced. Don't input confidential data outside the logged-in DMS module.
- Existing EdgeOne e-signing remains a pilot and is not certified digital-signature infrastructure. Avoid confidential/legal use without appropriate security and evidentiary review.

## Smartphone-only install into your existing GitHub repository

1. **Keep your existing EdgeOne signing repository and web domain unchanged.** Do not upload `TENCENTEDGEONE (Sequential Signing).zip` into your public DMS repository. That archive includes real signed PDFs, audit logs and client documents.
2. On GitHub, open `https://github.com/zenithloh1016/zhenli-dms/upload/main`, select `ZHENLI_DMS_TaskHub_Signing_Integration_Update.zip`, and commit the ZIP file. This ZIP contains only generic application code and no secret signing records.
3. Return to your *existing* GitHub Codespaces Terminal for `/workspaces/zhenli-dms`. Execute the following commands:

```bash
cd /workspaces/zhenli-dms
git pull --ff-only origin main
unzip -o ZHENLI_DMS_TaskHub_Signing_Integration_Update.zip
python3 scripts/apply_integration.py
node --check src/main.js
node --check src/integrated-modules.js
node --check public/task-hub/app.js
```

4. Review the changed files, then commit:

```bash
git add src/main.js src/integrated-modules.js src/integration.css public/task-hub supabase/task_hub_sync.sql scripts/apply_integration.py .github/workflows/deploy.yml INTEGRATION_SETUP.md
# Remove integration ZIP from the public repository after extracting it:
git rm -- ZHENLI_DMS_TaskHub_Signing_Integration_Update.zip
git commit -m "Add Task Hub V3 and existing EdgeOne signing access to DMS"
git push origin main
```

5. Open **Supabase → ZHENLI-DMS → SQL Editor → New Query**, open `supabase/task_hub_sync.sql` (inside GitHub Code or local Codespaces), copy all SQL, press **Run**. This adds a private task-hub table; it does NOT change the existing DMS folders. Confirm Success.
6. Obtain the **exact real HTTPS address** of the existing Tencent EdgeOne Sequential Signing administrator login page from EdgeOne Pages → project → Domains. In `zhenli-dms` GitHub → Settings → Secrets and variables → Actions → Variables, add:
    - Name: `VITE_EDGEONE_SIGNING_URL`
    - Value: the **root HTTPS URL** of your original signing website (e.g. `https://your-project.edgeone.app/`). Never include `?token=...`, signing invitation links, APP_SECRET, or credentials.
   If you omit this variable, the Signing tab shows instructions instead of linking an unknown website.
7. In GitHub Actions → **Deploy DMS Web and Build Android APK** → Run workflow on `main`, wait until `web` and `android` succeed. If one fails, open its error log. Github Pages will refresh to `https://zenithloh1016.github.io/zhenli-dms/` after deploy. APK builds are available under **Artifacts**; download fresh APK for Android installation.
8. Sign in to DMS, open **Task Hub**, check the Cloud sync label and create ONE disposable task. Refresh and verify persistence. Sign into the **same DMS account** on the other device and verify that task appears. Do not upload confidential files until this passes.
9. In the Signing tab, tap **Open existing Signing Website**. Test with non-sensitive sample PDFs only and verify that its existing drafts and signers have not been changed.

## Security and data handling

- No confidential ZIP content, signer tokens, passwords, signed PDFs, or audit JSON from the uploaded signing archive are included in the new integration ZIP.
- Keep the new Task Hub SQL table private with Row Level Security. Do not disable RLS.
- Do not paste `service_role` or Supabase secret keys into GitHub variables, HTML, or ZIP files. Only browser-safe Supabase Publishable / anon key.
- This package modifies project source when you run `scripts/apply_integration.py` in your repository. Do not apply blindly on a significantly redesigned version; it checks expected anchors and refuses unknown code layouts.
- Back up your old Task Hub JSON **before** migration; this bundle does not extract task data from local browser storage automatically.

## Source review of supplied archives

Archive `ZHENLI_Secretarial_Task_Hub_V3_EdgeOne_Deploy.zip` contains the Task Hub V3 static website (`app.js`, `index.html`, `styles.css`, `favicon.svg`). This release is the base for Task Hub features; its existing frontend operation is maintained and a cloud storage bridge is added for authenticated DMS embedding.

Archive `TENCENTEDGEONE (Sequential Signing).zip` contains five separate signing source/patch variants: `ZHENLI_EdgeOne_GitHub_Ready`, `ZHENLI_EdgeOne_Signature_Coordinates_Update`, `ZHENLI_EdgeOne_Signed_PDF_Compatibility_Fix`, `ZHENLI_EdgeOne_PDF_Viewer_Static_JS_Fix`, `ZHENLI_EdgeOne_Delete_Draft_Plus_PDF_Preview_Fix`, plus an authentication fix. It also includes real signed documents and audits. Since these are incremental fixes rather than a verified complete deployed snapshot, this DMS update deliberately DOES NOT replace the live EdgeOne code. Use its existing deployment to retain the exact real signing behavior and storage.

## Verification performed / not performed

- Checked JavaScript syntax with Node.js for integration, Task Hub bridge and selected EdgeOne patch scripts.
- Tested the patch script against the original DMS repository source and checked for the original Excel column helper and worksheet parser corrections.
- NOT live-tested against your authenticated Supabase instance, EdgeOne Pages production instance, GitHub Actions build or installed Android device. Deployment and user acceptance testing remain necessary.
