#!/usr/bin/env python3
"""Add an authenticated DMS API *adapter* to existing EdgeOne API, without replacing signing code.
Requires: DMS_SUPABASE_URL, DMS_SUPABASE_PUBLISHABLE_KEY, DMS_ADMIN_UID, DMS_ALLOWED_ORIGINS in EdgeOne secrets.
Allowed origins are exact origins (not paths or wildcards); admin UID required even after JWT is verified.
"""
from pathlib import Path
root=Path(__file__).resolve().parents[2]
api=root/'cloud-functions/api/[[default]].js'
if not api.exists():raise SystemExit('EdgeOne source not found: cloud-functions/api/[[default]].js. No changes.')
s=api.read_text()
if 'ZHENLI DMS VERIFIED BEARER BRIDGE' in s:
    print('Already patched. No changes.');raise SystemExit(0)
required=["const pathParts = (req) => new URL(req.url).pathname.split('/').filter(Boolean);",'async function handle(req,env,store) {','if(!currentSession(req,env))return failure(\'Administrator login required\',401);','export async function onRequest(context) {']
for anchor in required:
    if anchor not in s:raise SystemExit(f'Unexpected source: {anchor[:68]!r}. No changes made. Obtain current EdgeOne deployment source first.')
bridge='''// ZHENLI DMS VERIFIED BEARER BRIDGE (trusted admin only; no EdgeOne cookie or APP_SECRET in browser)
const dmsEnv = (env,name) => String(env?.[name] ?? process.env[name] ?? '').trim();
const dmsRoute = req => /^\\/api\\/dms\\/requests(?:\\/|$)/.test(new URL(req.url).pathname);
const dmsAllowedOrigin = (req,env) => {
  const origin = req.headers.get('origin') || '';
  const configured = dmsEnv(env,'DMS_ALLOWED_ORIGINS').split(',').map(s=>s.trim()).filter(Boolean);
  return origin && configured.includes(origin) ? origin : '';
};
const dmsCors = origin => ({
  'Access-Control-Allow-Origin':origin,
  'Access-Control-Allow-Methods':'GET, POST, DELETE, OPTIONS',
  'Access-Control-Allow-Headers':'Authorization, Content-Type, X-ZH-Request, X-File-Name',
  'Access-Control-Max-Age':'300','Vary':'Origin',
  'Cache-Control':'no-store'
});
async function verifiedDmsAdmin(req,env){
  const origin=dmsAllowedOrigin(req,env);
  if(!origin)return false;
  const url=dmsEnv(env,'DMS_SUPABASE_URL');
  const key=dmsEnv(env,'DMS_SUPABASE_PUBLISHABLE_KEY');
  const admin=dmsEnv(env,'DMS_ADMIN_UID');
  if(!/^https:\\/\\/[a-z0-9-]+\\.supabase\\.co\\/?$/.test(url) || !key || !/^[0-9a-f-]{36}$/i.test(admin))return false;
  const bearer=/^Bearer ([A-Za-z0-9._-]{100,4096})$/.exec(req.headers.get('Authorization')||'');
  if(!bearer)return false;
  try {
    const result=await fetch(url.replace(/\\/$/,'')+'/auth/v1/user',{
      method:'GET',headers:{'apikey':key,'Authorization':'Bearer '+bearer[1]},redirect:'error',cache:'no-store',signal:AbortSignal.timeout(6500)
    });
    if(!result.ok)return false;
    const user=await result.json();
    return user.id===admin && !!user.email_confirmed_at;
  }catch{return false;}
}
'''
s=s.replace("const pathParts = (req) => new URL(req.url).pathname.split('/').filter(Boolean);", "const pathParts = (req) => new URL(req.url).pathname.split('/').filter(Boolean);\n"+bridge,1)
s=s.replace("  const parts=pathParts(req), method=req.method;", """  const parts=pathParts(req), method=req.method;
  const dmsAdminRequest = dmsRoute(req);
  if(dmsAdminRequest) {
    if (!await verifiedDmsAdmin(req,env)) return failure('DMS administrator authorization failed or DMS bridge is not configured',401);
    parts.splice(1,1); // /api/dms/requests/... -> original trusted /api/requests/... handlers
  }""",1)
s=s.replace("if(method!=='GET'&&method!=='HEAD'&&(!originOK(req)||req.headers.get('x-zh-request')!=='1'))", "if(!dmsAdminRequest&&method!=='GET'&&method!=='HEAD'&&(!originOK(req)||req.headers.get('x-zh-request')!=='1'))",1)
s=s.replace("if(!currentSession(req,env))return failure('Administrator login required',401);", "if(!dmsAdminRequest && !currentSession(req,env))return failure('Administrator login required',401);",1)
old='''export async function onRequest(context) {
  try {
    return await handle(context.request,context.env||process.env,getStore(STORE_NAME));
  } catch(err) {
    // No internal detail to unauthenticated visitors. Inspect server logs for errors.
    console.error('Signing request failed:',err?.message||err);
    return failure('Service temporarily unavailable. Please retry later.',500);
  }
}'''
new='''export async function onRequest(context) {
  const req=context.request, env=context.env||process.env;
  const dms=dmsRoute(req);
  const origin=dms ? dmsAllowedOrigin(req,env) : '';
  if(dms && !origin) return failure('Origin not allowed',403);
  if(dms && req.method==='OPTIONS') return new Response(null,{status:204,headers:dmsCors(origin)});
  let result;
  try {
    result=await handle(req,env,getStore(STORE_NAME));
  } catch(err) {
    console.error('Signing request failed:',err?.message||String(err));
    result=failure('Service temporarily unavailable. Please retry later.',500);
  }
  // Attach CORS only to the dedicated DMS bridge, never to signer or existing admin endpoints.
  if(!dms)return result;
  const headers=new Headers(result.headers);
  for(const [key,value] of Object.entries(dmsCors(origin))) headers.set(key,value);
  return new Response(result.body,{status:result.status,statusText:result.statusText,headers});
}'''
if old not in s:raise SystemExit('Original request wrapper changed. No changes made.')
s=s.replace(old,new,1)
api.write_text(s)
print('EdgeOne DMS bridge installed. Configure FOUR required EdgeOne environment variables and redeploy EdgeOne.')
