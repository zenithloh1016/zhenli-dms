from pathlib import Path
root=Path(__file__).resolve().parents[1]
text=(root/'src/signing-workspace.js').read_text()
assert 'VITE_EDGEONE_SIGNING_URL' in text
assert 'createSignedUrl' not in text
assert "method:'POST'" in text
assert "dms-private" in text
p=(root/'edgeone/scripts/apply_dms_connector.py').read_text()
for name in ('DMS_ADMIN_UID','DMS_ALLOWED_ORIGINS','DMS_SUPABASE_URL','DMS_SUPABASE_PUBLISHABLE_KEY'):
    assert name in p
print('Checks passed: integrated workflow, authorized EdgeOne bridge, no embedded credentials.')
