# ZHENLI DMS — Create Signing Requests Inside DMS (Web and Android)

This add-on provides a DMS-native signing form connected to the **existing Tencent EdgeOne backend**, using Supabase authentication. The user creates, uploads PDFs, adds signature positions, activates sequential signing and monitors signers in the DMS. Invitees continue signing on the original EdgeOne site. No signing documents, passwords, existing requests, or signing database are bundled in this ZIP.

**Deployment state:** The add-on source is prepared and syntax-checked against the archived DMS integration and an archived EdgeOne backend. **Neither of your live services has been changed.** The live EdgeOne backend may have further fixes, so the patch refuses to apply if the expected source structure differs. Complete BOTH deployments before testing in DMS.

## What you get

- A Signing tab with **Create request**; choose company from current private DMS portfolio
- Enter subject, sender note, validity (1–60 days), and signers in sequential order; add/reorder/delete signers
- Upload up to 8 original PDFs (3 MB each) from device or select existing PDFs stored in DMS company folders
- View existing EdgeOne signing requests, signers, statuses and downloadable PDFs
- Add/edit signature *placement list* using exact PDF page and percentage-based X/Y/width/height; save fields before activation
- Activate sequential signing and use existing EdgeOne SMTP/email invitations; resend, copy sign links, delete drafts
- Download audit ZIP, download signed PDFs, or manually file completed signed PDFs to **Board & Members' Resolution** (idempotent by request/doc ID)
- Web and APK share the SAME EdgeOne signing requests; the EdgeOne signing portal stays live and unchanged except for the optional authenticated DMS connector

**Limitations:** The DMS coordinates form is numeric, not the original PDF drag/resize preview. For visual positioning you can still open the unchanged EdgeOne admin editor. There is no automatic filing or task status update. It is a pilot electronic signing system, not a legally certified signing provider. Verify the local regulatory and evidentiary suitability of electronic signatures for each document.

## Before starting

1. Back up the current GitHub repositories and confirm signing data remains stored in EdgeOne Pages Blob; never publish production signing data or any signed documents.
2. You need your **existing** EdgeOne signing website URL and its **CURRENT live backend source** (not just one historical patch). If you cannot access that code, stop after deploying DMS UI and request help locating the EdgeOne project.
3. In Supabase `Authentication → Users`, copy your own confirmed DMS login's **UUID** (not a password). It will be used to authorize only that account.

## A. Deploy the DMS UI (your current `zhenli-dms` GitHub Codespaces)

On your phone, use GitHub's repository upload page for `https://github.com/zenithloh1016/zhenli-dms/upload/main` to upload **`ZHENLI_DMS_InApp_Signing_Update.zip`**. After it is committed, open Codespaces Terminal and run:

```bash
cd /workspaces/zhenli-dms
git pull --ff-only origin main
unzip -o ZHENLI_DMS_InApp_Signing_Update.zip
python3 scripts/apply_signing_update.py
node --check src/main.js
node --check src/integrated-modules.js
node --check src/signing-workspace.js
# GitHub Actions will run its own Vite build.
git add src/main.js src/integrated-modules.js src/signing-workspace.js src/signing-workspace.css scripts/apply_signing_update.py .github/workflows/deploy.yml
git rm -- ZHENLI_DMS_InApp_Signing_Update.zip
git commit -m "Create EdgeOne signing requests directly in DMS"
git push origin main
```

If you see `Expected the existing INTEGRATED DMS source`, **stop** and send the complete error. This patch requires the earlier Task Hub + Signing integration to exist; it will not overwrite a substantially changed DMS source.

In GitHub repository **Settings → Secrets and variables → Actions → Variables**, check the existing public variable:

- `VITE_EDGEONE_SIGNING_URL` = `https://YOUR-ACTUAL-EDGEONE-SIGNING-DOMAIN/`

Do **not** use an individual signer invite, do not add a `token`, and do not put `ADMIN_PASSWORD`, `APP_SECRET`, or service-role keys into GitHub Actions variables. Re-run **Deploy DMS Web and Build Android APK**. Wait for BOTH jobs to succeed and install the fresh APK if needed.

## B. Patch the CURRENT EdgeOne signing backend (separate existing EdgeOne source repo)

Do **not** blindly overwrite EdgeOne with any archive file; doing so could remove fixes made after the source snapshot. The patch edits only the EdgeOne handler to add `/api/dms/requests/...`; the original admin and signer endpoints stay unchanged.

Upload this ZIP into the **existing repository that EdgeOne Pages deploys**. From that repository's Codespaces Terminal, with its root `cloud-functions/api/[[default]].js` present, run:

```bash
unzip -p ZHENLI_DMS_InApp_Signing_Update.zip edgeone/scripts/apply_dms_connector.py > /tmp/apply_dms_connector.py
mkdir -p edgeone/scripts
cp /tmp/apply_dms_connector.py edgeone/scripts/apply_dms_connector.py
python3 edgeone/scripts/apply_dms_connector.py
node --check 'cloud-functions/api/[[default]].js'
git add 'cloud-functions/api/[[default]].js' edgeone/scripts/apply_dms_connector.py
git rm -- ZHENLI_DMS_InApp_Signing_Update.zip
git commit -m "Add verified Supabase DMS admin connector"
git push origin main
```

If the repo is NOT hosted on GitHub, edit/deploy the live EdgeOne source by its existing supported process, making a backup first. If a patch anchor cannot be found, it prints a clear error and changes nothing. **Do not substitute the old archived handler** for the currently deployed EdgeOne handler.

In **Tencent EdgeOne Pages → Project → Settings → Environment Variables**, configure these 4 settings (server-side, NOT in public DMS files):

| Name | Value |
|---|---|
| `DMS_SUPABASE_URL` | Base URL of your existing ZHENLI-DMS Supabase project, ending in `.supabase.co` without `/rest/v1` |
| `DMS_SUPABASE_PUBLISHABLE_KEY` | The Supabase publishable key (`sb_publishable_...`) or legacy anon key |
| `DMS_ADMIN_UID` | EXACT Supabase Auth User UUID of the one authorized DMS administrator |
| `DMS_ALLOWED_ORIGINS` | `https://zenithloh1016.github.io,https://localhost` |

`https://localhost` is for the Android Capacitor app using `androidScheme=https`, not for random websites. Do not add `*` or untrusted origins. Both Supabase Auth and the exact UID check must succeed before any signing request can be created. Your existing EdgeOne `APP_SECRET`, `ADMIN_PASSWORD`, Blob storage, and SMTP settings remain unchanged.

**Redeploy EdgeOne Pages** after updating code and environment variables. EdgeOne URL and Supabase settings are not sent to end-user-visible code beyond the public project URL and publishable key.

## C. Test the integration (non-sensitive sample only)

1. Sign in to DMS and open **Signing**. The old "Open signing website" card should be replaced with **Sequential Signing Requests**.
2. Tap **Create request**; choose one DMS company, give a test subject, add one signer (your own accessible test email), upload a small test PDF, then create a draft.
3. Open the draft, enter the signer/page/box coordinates, press **Save positions**, then press **Activate**.
4. Check that the signer receives the original EdgeOne email or that the correct invite link can be copied; confirm its URL begins with your real EdgeOne domain.
5. Sign the test PDF using the original EdgeOne signing page; return to the DMS Signing tab and refresh.
6. If status is `completed`, use **Save signed PDFs to DMS**. Verify the file under the company's **Board & Members' Resolution** folder.
7. Test the same DMS user account in your Android app; build a fresh APK, because the previous APK does not have the Signing tab updates.
8. Check any audit/record retention requirements before deploying for real company statutory documents.

## Troubleshooting

- `DMS administrator authorization failed`: verify `DMS_ADMIN_UID` is exactly your Supabase Auth user ID, the JWT is for your confirmed account, and the base URL/publishable key are correct.
- Browser `CORS` error: check `DMS_ALLOWED_ORIGINS` exact origins (web uses `https://zenithloh1016.github.io`; Android normally `https://localhost`). Redeploy EdgeOne after changing env.
- `404` for `/api/dms/requests`: the EdgeOne connector has not deployed, or it was patched into the wrong EdgeOne project.
- `503` server not configured: the original EdgeOne `APP_SECRET` and `ADMIN_PASSWORD` must still be configured.
- `Email failed; share link manually`: check original EdgeOne SMTP environment variables; do not place SMTP password in DMS.
- `only 3 MB`: the existing EdgeOne pilot backend limits each PDF to 3 MB. DMS storage limit (50 MB) is independent.
- `Already patched`: idempotent patch scripts; don't run source patches repeatedly.

## Confidentiality

This ZIP contains only new UI and patch scripts—no Task Hub backups, client listing, EdgeOne Blob exports, signing tokens, actual signed PDFs, passwords, or API secrets. You can temporarily upload the ZIP into a public source repository for installation, but remove the ZIP from the current branch afterward as shown above. For confidential source or code, private repositories are preferable.
