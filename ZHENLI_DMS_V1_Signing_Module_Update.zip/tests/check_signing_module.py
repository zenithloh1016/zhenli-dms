from pathlib import Path
base=Path(__file__).resolve().parents[1]
main=(base/'src/main.js').read_text()
module=(base/'src/signing-workspace.js').read_text()
yaml=(base/'.github/workflows/deploy.yml').read_text()
assert "if(state.page==='signing')queueMicrotask(restoreSigningWorkspace);" in main
assert "initSigningWorkspace(db,()=>state.user,()=>state.companies)" in main
assert "VITE_EDGEONE_SIGNING_URL:" in yaml
assert "!u.loaded" in module and "resetSigningWorkspace" in module
assert "api/dms/requests" in module
assert "getSession()" in module
assert "signingWorkspaceHTML()" in main
print("Structural checks passed (not a live service test).")
