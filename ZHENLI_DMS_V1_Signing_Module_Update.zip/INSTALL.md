# ZHENLI DMS 1.0 — Direct Sequential Signing integration

**This is an incremental update to the uploaded DMS Version 1.0.** It adds a new **Sequential Signing** tab accessible on web and Android, including a request form, company selection, PDF uploads, ordered signers, percentage-based signature boxes, status tracking, and a button to open the original EdgeOne site.

## What it DOES NOT change

- Supabase database tables, row-level security, or the `dms-private` storage bucket.
- Company folders, Excel Master Listing importer, document uploads, login, and their underlying records.
- Tencent EdgeOne signing source, stored requests, invitation tokens, or private PDFs.
- No Task Hub migration or Task Hub module is included.

## Preconditions — check before publishing

1. Your **Tencent EdgeOne** `zhenli-sequential-signing` production deployment must include the **authenticated `/api/dms/requests` bridge** that was installed earlier. A successful `npm run build` alone does **not** prove this.
2. The EdgeOne Production variables must have valid values for `DMS_SUPABASE_URL`, `DMS_SUPABASE_PUBLISHABLE_KEY`, `DMS_ADMIN_UID`, `DMS_ALLOWED_ORIGINS`. Allowed origins should include the exact website origin `https://zenithloh1016.github.io` and Android `https://localhost` (Capacitor).
3. On GitHub repository **zenithloh1016/zhenli-dms**, go to Settings → Secrets and variables → Actions → **Variables** and confirm `VITE_EDGEONE_SIGNING_URL` is the **root HTTPS URL of your existing EdgeOne signing website** (not an invitation link). Never put `APP_SECRET`, `ADMIN_PASSWORD`, an EdgeOne token, a Supabase service-role key, or SMTP credentials here.
4. Supabase users must be logged in as the UID in `DMS_ADMIN_UID` to use the DMS bridge. Other DMS users may manage their own documents but **cannot** manage requests through the EdgeOne connector.

## Recommended phone-only setup

1. **Backup** your DMS `main` revision, and ensure GitHub Actions web & Android were successful on Version 1.0.
2. Upload `ZHENLI_DMS_V1_Signing_Module_Update.zip` to **zhenli-dms**, not `ZHENLI-Sequential-Signing`.
3. Open **zhenli-dms Codespaces**. Use `pwd` to confirm `/workspaces/zhenli-dms`.
4. Run `git pull --ff-only origin main` then `unzip -o ZHENLI_DMS_V1_Signing_Module_Update.zip 'src/*' '.github/workflows/deploy.yml'`. This overwrites only the named frontend files and GitHub workflow from the verified Version 1.0 source; no SQL or client data is included.
5. Run `node --check src/main.js && node --check src/signing-workspace.js && npm run build`.
6. Check `git diff --stat` and `git status --short`. If no error, stage **only** the intended files: `git add src/main.js src/style.css src/signing-workspace.js src/signing-workspace.css .github/workflows/deploy.yml`.
7. Commit `git commit -m "Add standalone Signing to DMS Version 1.0"` and push `git push origin main`. Do not force push.
8. Verify the GitHub Actions jobs `web` and `android` are green. The APK is the **Android debug artifact** of that successful run.
9. Sign in to DMS → **Sequential Signing**. First test with a sample nonconfidential PDF, then test signatory links, signature boxes and completed PDF retrieval **before** using company resolutions.

## Important limitations

- The form uses percentage-based signature boxes (X/Y/width/height). For precise visual placement use **Original EdgeOne site ↗**. The form should never activate without at least one saved signature box per signer.
- The backend returns verified signing status. This has **not** been end-to-end verified against your live EdgeOne or Supabase instance in this environment.
- GitHub Pages is a static web host; the browser calls EdgeOne. Wrong URL, missing API, wrong allowed origins, and an invalid admin UID can cause a failed request. `Failed to fetch` is not fixed by simply running `npm run build`.
- This adds no new privilege in Supabase and sends no privileged EdgeOne or Supabase secrets to frontend code.
- On Android, Capacitor Browser opens the original EdgeOne site externally/in-app as supported; the direct administration form is embedded in DMS.
