# Restore earlier DMS Signing tab — Existing EdgeOne service only

This update ONLY replaces `src/signing-workspace.js` and `src/signing-workspace.css` in the **zhenli-dms** repository. It does not modify Document Management code, Task Hub, EdgeOne backend, Supabase schema or storage.

1. Upload this ZIP to the **zhenli-dms** GitHub repository and commit the ZIP only.
2. Open **zhenli-dms Codespaces**.
3. Pull new ZIP: `git pull --ff-only origin main` (if this fails, stop and inspect local tracked changes).
4. Back up current branch: `git branch backup-signing-module-before-panel-restore-$(date +%Y%m%d%H%M%S)`.
5. Extract ONLY the two module files: `unzip -o 'ZHENLI_DMS_Restore_Original_Signing_Panel.zip' 'src/signing-workspace.js' 'src/signing-workspace.css'`.
6. Verify: `node --check src/signing-workspace.js && npm run build && git diff --check && git diff --stat`.
7. Check the diff carefully; stage ONLY the two files, commit, and push after confirming the build and backups.
8. In GitHub Actions Variables set `VITE_EDGEONE_SIGNING_URL` to the **HTTPS URL of the original EdgeOne signing app**, then redeploy web and Android. A missing URL produces the original informational notice.

This restores the panel only: it does not provide in-app request creation. A separate EdgeOne website opens on user click and existing credentials/signed PDFs remain on Tencent EdgeOne.
